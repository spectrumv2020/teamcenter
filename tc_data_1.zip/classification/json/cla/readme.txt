==================================================
    Copyright 2020.
    Siemens Product Lifecycle Management Software Inc.
    All Rights Reserved.
==================================================

GetClassificationObjects_Request.schema.json
    1.1.0 - Added Tc 12.4.0. - Support for getting or deleting Library elements or classification objects.

SaveClassificationObjects_Request.schema.json
    1.1.0 - Added Tc 12.4.0. - Support for creating Library elements or classification objects.
	1.2.0 - Added Tc 13.3.0. - Support for multiple classification

