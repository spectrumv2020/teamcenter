==================================================
    Copyright 2020.
    Siemens Industry Software Inc.
    All Rights Reserved.
==================================================

Classification_Save_ClassDefinitions_Request.schema.json
    1.1.0 - Starting Tc 12.4.0 - Support for interdependency configuration "Dependency Attribute" and "Dependency Configuration" added.
            Support to configure multiple classification functionality.
            Added SMLSyncDate to support reports from the migration utility.
    1.2.0 - Starting Tc13.1.0 - Support for multiple eCl@ss releases by adding the option "AddAsNewRelease"

Classification_Save_KeyLOVDefinitions_Request.schema.json
    1.1.0 - Starting Tc12.4.0 - Support for deprecated values and the "Hide key" functionality.
            If a KeyLOVDefinition item is deprecated it cannot be used for classifying objects (although you can use it when searching for classified objects).
            You can hide the display of key of the KeyLOVDefinition in the user interface by setting "IsHideKey" to true.
            Added SMLSyncDate to support reports from the migration utility.
    1.2.0 - Starting Tc13.1.0 - Support for multiple eCl@ss releases by adding the option "AddAsNewRelease"

Classification_Save_PropertyDefinitions_Request.schema.json
    1.1.0 - Starting Tc12.4.0 - Support for Position, Axis, Value_Range, Value_With_Tolerance, and Level complex data types.
            Each complex data type requires multiple values to be specified:
                Position: PosX, PosY, PosZ
                Axis: PosX, PosY, PosZ, RotX, RotY, RotZ
                Value_Range: Min, Max
                Value_With_Tolerance: Nominal, Min, Max
                Level: Nominal, Typical, Min, Max
            Added SMLSyncDate to support reports from the migration utility.
    1.2.0 - Starting Tc13.1.0 - Support for multiple eCl@ss releases by adding the option "AddAsNewRelease"

Classification_Save_PropertyRecords_Request.schema.json
    1.1.0 - Starting Tc12.4.0 - Support for Position, Axis, Value_Range, Value_With_Tolerance, and Level complex data types.

Classification_Save_NodeDefinitions_Request.schema.json
    1.1.0 - Starting Tc13.1.0 - Support for read-only property, "NodeId". This uniquely identifies a NodeDefinition.
            Primarily used while searching for NodeDefinitions.
            The property, "Revision" is made mandatory for a NodeDefinition, Parent and ApplicationClass.
            Support for multiple eCl@ss releases by adding the option "AddAsNewRelease".
            Added the property, "SourceStandard". This is the identifier of the standard the NodeDefinition is based on.
